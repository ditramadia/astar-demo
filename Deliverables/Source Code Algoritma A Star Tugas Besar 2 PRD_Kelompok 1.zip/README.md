# TUGAS BESAR PENGENALAN REKAYASA DAN
## Anggota:
- Ahmad Nadil (16521516@std.stei.itb.ac.id
- Adrian Fahri Affandi (16521503@std.stei.itb.ac.id
- Justin Yusuf Abidjoko (16521494@std.stei.itb.ac.id
- Ditra Rizqa Amadia (16521531@std.stei.itb.ac.id
- Kelvin Rayhan Alkarim (16521496@std.stei.itb.ac.id
- Raditya Naufal Abiyu (16521534@std.stei.itb.ac.id

## Dosen:
- Dr.Eng. Infall Syafalni, S.T., M.Sc.

### Shortest Path Algorithm pada Aplikasi Google Maps menggunakan Algoritma A* pada bahasa Python

## Cara Menjalankan :
1. Ini meurpakan contoh graph tree yang kami gunakan
![](https://raw.githubusercontent.com/ditramadia/astar-demo/master/Node%20Contoh.jpg)
2. Input Node Awal dan Akhir pada program

    `Starting Node : A`

    `Stopping Node : L`
3. Path akan ditemukan

    ` Path found : ['A', 'C', 'E', 'G', 'H', 'L'] `

4. Jika ingin melakukan perhitungan pada graph lain, dapat dilakukan perubahan pada bagian input dan fungsi gScore